using Godot;

namespace NewGameProject.Scripts;

public partial class Game : Node2D
{
    public override void _Ready()
    {
        
    }
}