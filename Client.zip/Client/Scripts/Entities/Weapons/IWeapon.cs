namespace NewGameProject.Scripts.Entities.Weapons;

public interface IWeapon
{
    
}