namespace NewGameProject.Scripts.Entities.Enemies.Monsters;

public partial class Goblin : Enemy
{
    
}