using Godot;

namespace NewGameProject.Scripts.Components.Interfaces;

public interface IAttackComponent
{
    
}