using System.Collections.Generic;
using NewGameProject.Scripts.Components;
using Godot;
using NewGameProject.Scripts.Entities.Weapons;
using Array = Godot.Collections.Array;

namespace NewGameProject.Scripts.Systems.Utilities;

public partial class SignalBus : Node
{
    
}