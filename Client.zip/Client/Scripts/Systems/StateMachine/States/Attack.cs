namespace NewGameProject.Scripts.Systems.StateMachine.States;

public class Attack
{
    
}