using Godot;

namespace NewGameProject.Scripts.Combat;

public partial class WeaponHitContext : Node
{
    
}